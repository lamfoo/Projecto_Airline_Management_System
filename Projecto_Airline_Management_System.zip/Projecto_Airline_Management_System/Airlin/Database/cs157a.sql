-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 28-Nov-2021 às 10:04
-- Versão do servidor: 10.4.21-MariaDB
-- versão do PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `cs157a`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `archive`
--

CREATE TABLE `archive` (
  `flightID` int(11) NOT NULL,
  `destination` varchar(255) DEFAULT NULL,
  `depDate` date DEFAULT NULL,
  `depTime` time DEFAULT NULL,
  `planeID` int(11) DEFAULT NULL,
  `pilotID` int(11) DEFAULT NULL,
  `gateID` char(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `archive`
--

INSERT INTO `archive` (`flightID`, `destination`, `depDate`, `depTime`, `planeID`, `pilotID`, `gateID`) VALUES
(101, 'Tokyo, Japan', '2013-12-25', '01:20:00', 1234, 10, 'A001'),
(102, 'Manilla, Philippines', '2013-11-02', '13:00:00', 1867, 11, 'A002'),
(103, 'New Dehli, India', '2013-11-25', '13:30:00', 2685, 1, 'A003'),
(104, 'Zurich, Switzerland', '2013-11-06', '01:45:00', 3212, 2, 'A004'),
(105, 'Taipei, Taiwan', '2013-12-07', '06:50:00', 4325, 3, 'A002'),
(106, 'Seoul, Korea', '2014-01-02', '09:15:00', 5432, 4, 'A001'),
(107, 'Taipei, Taiwan', '2014-01-19', '16:10:00', 6987, 5, 'A004'),
(108, 'New Delhi, India', '2013-12-20', '15:00:00', 7234, 6, 'A003');

-- --------------------------------------------------------

--
-- Estrutura da tabela `Flight`
--

CREATE TABLE `Flight` (
  `flightID` int(11) NOT NULL,
  `destination` varchar(255) DEFAULT NULL,
  `depDate` date DEFAULT NULL,
  `depTime` time DEFAULT NULL,
  `planeID` int(11) DEFAULT NULL,
  `pilotID` int(11) DEFAULT NULL,
  `gateID` char(4) DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `Flight`
--

INSERT INTO `Flight` (`flightID`, `destination`, `depDate`, `depTime`, `planeID`, `pilotID`, `gateID`, `updatedAt`) VALUES
(102, 'Manilla, Philippines', '2013-11-02', '13:00:00', 1867, 11, 'A002', '2021-11-27 10:04:17'),
(103, 'New Dehli, India', '2013-11-25', '13:30:00', 2685, 1, 'A003', '0000-01-01 00:00:00'),
(104, 'Zurich, Switzerland', '2013-11-06', '01:45:00', 3212, 2, 'A004', '0000-01-01 00:00:00'),
(105, 'Taipei, Taiwan', '2013-12-07', '06:50:00', 4325, 3, 'A002', '0000-01-01 00:00:00'),
(106, 'Seoul, Korea', '2014-01-02', '09:15:00', 5432, 4, 'A001', '0000-01-01 00:00:00'),
(107, 'Taipei, Taiwan', '2014-01-19', '16:10:00', 6987, 5, 'A004', '0000-01-01 00:00:00'),
(108, 'New Delhi, India', '2013-12-20', '15:00:00', 7234, 6, 'A003', '0000-01-01 00:00:00'),
(109, 'Maputo', '2021-10-25', '22:22:02', 4050, 12, 'A005', '2021-11-12 17:52:45');

-- --------------------------------------------------------

--
-- Estrutura da tabela `Passenger`
--

CREATE TABLE `Passenger` (
  `name` char(30) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `flightID` int(11) DEFAULT NULL,
  `firstClass` tinyint(1) DEFAULT NULL,
  `seatID` char(3) DEFAULT NULL,
  `pasID` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `Passenger`
--

INSERT INTO `Passenger` (`name`, `age`, `flightID`, `firstClass`, `seatID`, `pasID`) VALUES
('Jim Nelson', 54, 101, 0, 'A01', '102C'),
('Billy Norton', 19, 101, 0, 'A02', '103C'),
('Allison Bingham', 32, 101, 0, 'A03', '104C'),
('Lucy Chen', 25, 101, 0, 'A04', '105C'),
('Shivalik Narad', 22, 101, 1, 'A07', '106C'),
('Andrew Jones', 25, 101, 0, 'A05', '107C'),
('Tyler Stennette', 23, 101, 0, 'A06', '108C'),
('Joseph Coorey', 23, 101, 0, 'B01', '109C'),
('Joshua Filstrup', 24, 101, 0, 'B02', '110C'),
('Donvale', 25, 106, 0, 'F06', '440C'),
('Foo', 80, 107, 0, 'B09', '789C');

--
-- Acionadores `Passenger`
--
DELIMITER $$
CREATE TRIGGER `updateSeat` AFTER INSERT ON `Passenger` FOR EACH ROW BEGIN 
UPDATE Seat SET Seat.taken = true
WHERE Seat.sID = new.seatID;

END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateSeatFalse` BEFORE DELETE ON `Passenger` FOR EACH ROW BEGIN 
UPDATE Seat SET Seat.taken = false
WHERE Seat.sID = old.seatID;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `Pilot`
--

CREATE TABLE `Pilot` (
  `pName` char(30) DEFAULT NULL,
  `pilotID` int(11) NOT NULL,
  `yrExp` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `Pilot`
--

INSERT INTO `Pilot` (`pName`, `pilotID`, `yrExp`) VALUES
('Shannon Moody', 1, 5),
('Rita King', 2, 15),
('Jan Morris', 3, 1),
('James Doolittle', 4, 7),
('Noel Wein', 5, 14),
('Robert Hoover', 6, 9),
('Charles Lindbergh', 7, 13),
('Charles Yeager', 8, 17),
('Fox McCloud', 10, 10),
('Pete Mitchell', 11, 6),
('Marcos', 12, 25);

-- --------------------------------------------------------

--
-- Estrutura da tabela `PLANE`
--

CREATE TABLE `PLANE` (
  `planeID` int(11) NOT NULL,
  `age` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `Plane`
--

CREATE TABLE `Plane` (
  `planeID` int(11) NOT NULL,
  `age` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `Plane`
--

INSERT INTO `Plane` (`planeID`, `age`) VALUES
(1234, 7),
(1867, 13),
(2685, 1),
(3212, 20),
(4325, 5),
(4565, 9),
(5432, 15),
(6987, 9),
(7234, 16),
(52013, 11);

-- --------------------------------------------------------

--
-- Estrutura da tabela `Seat`
--

CREATE TABLE `Seat` (
  `sID` char(3) NOT NULL,
  `row` char(1) DEFAULT NULL,
  `seatNo` int(11) DEFAULT NULL,
  `taken` tinyint(1) DEFAULT NULL,
  `planeID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `Seat`
--

INSERT INTO `Seat` (`sID`, `row`, `seatNo`, `taken`, `planeID`) VALUES
('A01', 'A', 1, 1, 1234),
('A02', 'A', 2, 1, 1234),
('A03', 'B', 1, 1, 1234),
('A04', 'B', 2, 1, 1234),
('A05', 'C', 1, 1, 1234),
('A06', 'C', 2, 1, 1234),
('A07', 'F', 1, 1, 1234),
('A08', 'F', 2, 0, 1234),
('B01', 'A', 1, 1, 1867),
('B02', 'A', 2, 1, 1867),
('B03', 'B', 1, 1, 1867),
('B04', 'B', 2, 0, 1867),
('B05', 'C', 1, 0, 1867),
('B06', 'C', 2, 0, 1867),
('B07', 'F', 1, 0, 1867),
('B08', 'F', 2, 0, 1867),
('C01', 'A', 1, 0, 2685),
('C02', 'A', 2, 0, 2685),
('C03', 'B', 1, 0, 2685),
('C04', 'B', 2, 0, 2685),
('C05', 'C', 1, 0, 2685),
('C06', 'C', 2, 0, 2685),
('C07', 'F', 1, 0, 2685),
('C08', 'F', 2, 0, 2685),
('D01', 'A', 1, 0, 3212),
('D02', 'A', 2, 0, 3212),
('D03', 'B', 1, 0, 3212),
('D04', 'B', 2, 0, 3212),
('D05', 'C', 1, 0, 3212),
('D06', 'C', 2, 0, 3212),
('D07', 'F', 1, 0, 3212),
('D08', 'F', 2, 0, 3212),
('E01', 'A', 1, 0, 4325),
('E02', 'A', 2, 0, 4325),
('E03', 'B', 1, 0, 4325),
('E04', 'B', 2, 0, 4325),
('E05', 'C', 1, 0, 4325),
('E06', 'C', 2, 0, 4325),
('E07', 'F', 1, 0, 4325),
('E08', 'F', 2, 0, 4325),
('F01', 'A', 1, 0, 5432),
('F02', 'A', 2, 0, 5432),
('F03', 'B', 1, 0, 5432),
('F04', 'B', 2, 0, 5432),
('F05', 'C', 1, 0, 5432),
('F06', 'C', 2, 1, 5432),
('F07', 'F', 1, 0, 5432),
('F08', 'F', 2, 0, 5432),
('G01', 'A', 1, 0, 6987),
('G02', 'A', 2, 0, 6987),
('G03', 'B', 1, 0, 6987),
('G04', 'B', 2, 0, 6987),
('G05', 'C', 1, 0, 6987),
('G06', 'C', 2, 0, 6987),
('G07', 'F', 1, 0, 6987),
('G08', 'F', 2, 0, 6987),
('H01', 'A', 1, 0, 7234),
('H02', 'A', 2, 0, 7234),
('H03', 'B', 1, 0, 7234),
('H04', 'B', 2, 0, 7234),
('H05', 'C', 1, 0, 7234),
('H06', 'C', 2, 0, 7234),
('H07', 'F', 1, 0, 7234),
('H08', 'F', 2, 0, 7234);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `archive`
--
ALTER TABLE `archive`
  ADD PRIMARY KEY (`flightID`);

--
-- Índices para tabela `Flight`
--
ALTER TABLE `Flight`
  ADD PRIMARY KEY (`flightID`);

--
-- Índices para tabela `Passenger`
--
ALTER TABLE `Passenger`
  ADD PRIMARY KEY (`pasID`);

--
-- Índices para tabela `Pilot`
--
ALTER TABLE `Pilot`
  ADD PRIMARY KEY (`pilotID`);

--
-- Índices para tabela `PLANE`
--
ALTER TABLE `PLANE`
  ADD PRIMARY KEY (`planeID`);

--
-- Índices para tabela `Plane`
--
ALTER TABLE `Plane`
  ADD PRIMARY KEY (`planeID`);

--
-- Índices para tabela `Seat`
--
ALTER TABLE `Seat`
  ADD PRIMARY KEY (`sID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
